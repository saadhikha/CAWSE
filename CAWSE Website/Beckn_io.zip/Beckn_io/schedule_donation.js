//DOM elements
var firstname = document.getElementById('firstname')
var lastname = document.getElementById('lastname')
var gender
var male = document.getElementById('male')
var female = document.getElementById('female')
var others = document.getElementById('others')
var address = document.getElementById('address')
var phonenumber = document.getElementById('phonenumber')
var blood_group = document.getElementById('blood-group')
var medical_history = document.getElementById('medical-history')
var date = document.getElementById('date')
var submit = document.getElementById('submit')

//Variables
var socket = io();
console.log('Socket created successfully')

submit.addEventListener('click', function() {
    if(male.checked) gender = 'male'
    else if(female.checked) gender = 'female'
    else gender = 'unknown'
    console.log(gender)
    socket.emit('schedule_blood_donation', firstname.value, lastname.value, gender, address.value, 
        phonenumber.value, blood_group.value, medical_history.value, date.value)
    console.log('Scheduled successfully')
})