//DOM elements
var state = document.getElementById('state')
var city = document.getElementById('city')
var specialisation = document.getElementById('specialisation')
var pincode = document.getElementById('pincode')
var filter_table = document.getElementById('filter-table')
var filter_table_div = document.getElementById('filter-table-div')

//Variables
var socket = io();
console.log('Socket created successfully')

submit.addEventListener('click', function() {
    console.log(state.value)
    console.log(city.value)
    console.log(specialisation.value)
    socket.emit('doctors_availability', city.value+", "+state.value, specialisation.value)
});

socket.on('returning_result', function(result){
    filter_table_div.style.display = "block"
    console.log(result)
    var resultCount = result['length']
    for(i=1; i<=resultCount; i++) {
        var row = filter_table.insertRow(i)
        var cell1 = row.insertCell(0)
        var cell2 = row.insertCell(1)
        var cell3 = row.insertCell(2)
        var cell4 = row.insertCell(3)
        var cell5 = row.insertCell(4)
        var cell6 = row.insertCell(5)
        cell1.innerHTML = result[i-1]['name']
        cell2.innerHTML = result[i-1]['contact']
        cell3.innerHTML = result[i-1]['age']
        cell4.innerHTML = result[i-1]['hospital_name']
        cell5.innerHTML = result[i-1]['hospital_category']
        cell6.innerHTML = "<a href='booking_status.html'>Book Now</a>"
    }
});